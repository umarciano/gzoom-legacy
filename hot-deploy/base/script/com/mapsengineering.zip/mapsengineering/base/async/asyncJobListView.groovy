import org.ofbiz.base.util.*;
import com.mapsengineering.base.services.async.AsyncJobManager;

context.listIt = AsyncJobManager.getListView(userLogin.userLoginId);
